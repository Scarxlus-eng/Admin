"use client"

import { useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Pizza, Coffee, Plus, Minus, BarChart3, DollarSign, Package, Edit, Trash2, ShoppingCart } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"

interface PizzaFlavor {
  id: string
  name: string
  available: boolean
}

interface Drink {
  id: string
  name: string
  price: number
  available: boolean
}

// Agregar nueva interfaz para gaseosas personales después de la interfaz Drink
interface PersonalSoda {
  id: string
  brand: string // Marca de la gaseosa (Coca Cola, Pepsi, etc.)
  flavors: Array<{
    id: string
    name: string
    available: boolean
  }>
  price: number
  available: boolean
}

// Actualizar la interfaz PizzaInventory para manejar múltiples sabores
interface PizzaInventory {
  id: string
  flavors: Array<{
    name: string
    slices: number
    remainingSlices: number
  }>
  totalSlices: number
  remainingSlices: number
  type: "local" | "takeaway"
  pricePerSlice: number
  totalPrice: number
}

interface Sale {
  id: string
  type: "pizza" | "drink"
  item: string
  quantity: number
  price: number
  timestamp: Date
}

interface Expense {
  id: string
  description: string
  amount: number
  timestamp: Date
}

// Agregar nueva interfaz después de la interfaz Expense
interface Table {
  id: number
  isOccupied: boolean
  customerName?: string
  orders: Array<{
    id: string
    type: "pizza" | "drink"
    item: string
    quantity: number
    price: number
    timestamp: Date
  }>
  totalAmount: number
}

const PIZZA_PRICES = {
  local: 54000, // Para consumir en el lugar
  takeaway: 56000, // Para llevar
  perSlice: 4500, // Por porción
  caja: 56000, // En caja
  bolsa: 54000, // En bolsa
}

const DRINK_PRICES = {
  cocaCola: 7500,
  agua: 1000,
  hit: 3500,
}

export default function PizzeriaAdmin() {
  const [pizzaFlavors, setPizzaFlavors] = useState<PizzaFlavor[]>([
    { id: "1", name: "Hawaiana", available: true },
    { id: "2", name: "Jamón con Queso", available: true },
    { id: "3", name: "Jamón con Pollo", available: true },
    { id: "4", name: "Champiñones con Pollo", available: true },
    { id: "5", name: "Pepperoni", available: true },
    { id: "6", name: "Campesina", available: true },
    { id: "7", name: "Vasqueza", available: true },
    { id: "8", name: "Salami", available: true },
    { id: "9", name: "Mexicana", available: true },
    { id: "10", name: "Carnes Frías", available: true },
  ])

  const [drinks, setDrinks] = useState<Drink[]>([
    { id: "1", name: "Coca Cola 1.5lt", price: DRINK_PRICES.cocaCola, available: true },
    { id: "2", name: "Agua", price: DRINK_PRICES.agua, available: true },
    { id: "3", name: "HIT", price: DRINK_PRICES.hit, available: true },
  ])

  // Actualizar los estados iniciales después de drinks
  const [personalSodas, setPersonalSodas] = useState<PersonalSoda[]>([
    {
      id: "1",
      brand: "Coca Cola",
      flavors: [{ id: "1", name: "Original", available: true }],
      price: 2000,
      available: true,
    },
    {
      id: "2",
      brand: "Postobón",
      flavors: [
        { id: "1", name: "Manzana", available: true },
        { id: "2", name: "Uva", available: true },
        { id: "3", name: "Piña", available: true },
        { id: "4", name: "Pepsi", available: true },
        { id: "5", name: "Naranja", available: true },
        { id: "6", name: "Colombiana", available: true },
        { id: "7", name: "Kola", available: true },
      ],
      price: 2000,
      available: true,
    },
  ])

  const [pizzaInventory, setPizzaInventory] = useState<PizzaInventory[]>([])
  const [sales, setSales] = useState<Sale[]>([])
  const [expenses, setExpenses] = useState<Expense[]>([])

  // Agregar nuevo estado después de los estados existentes
  const [tables, setTables] = useState<Table[]>(
    Array.from({ length: 9 }, (_, index) => ({
      id: index + 1,
      isOccupied: false,
      customerName: "",
      orders: [],
      totalAmount: 0,
    })),
  )

  // Estados para formularios
  const [newFlavorName, setNewFlavorName] = useState("")
  const [newDrinkName, setNewDrinkName] = useState("")
  const [newDrinkPrice, setNewDrinkPrice] = useState("")

  // Agregar nuevos estados para formularios después de los estados existentes
  const [newSodaBrand, setNewSodaBrand] = useState("")
  const [newSodaPrice, setNewSodaPrice] = useState("")
  const [newSodaFlavor, setNewSodaFlavor] = useState("")

  const [selectedPizzaFlavor, setSelectedPizzaFlavor] = useState("")
  const [selectedPizzaType, setSelectedPizzaType] = useState<"local" | "takeaway">("local")
  const [expenseDescription, setExpenseDescription] = useState("")
  const [expenseAmount, setExpenseAmount] = useState("")

  // Estados para el servicio por mesa
  const [selectedTable, setSelectedTable] = useState<number | null>(null)
  const [customerName, setCustomerName] = useState("")
  const [selectedOrderType, setSelectedOrderType] = useState<"pizza" | "drink">("pizza")
  const [selectedPizzaForTable, setSelectedPizzaForTable] = useState("")
  const [selectedDrinkForTable, setSelectedDrinkForTable] = useState("none")
  const [selectedSodaForTable, setSelectedSodaForTable] = useState("none")
  const [selectedSodaFlavorForTable, setSelectedSodaFlavorForTable] = useState("")
  const [orderQuantity, setOrderQuantity] = useState(1)

  // Estados para edición
  const [editingPizza, setEditingPizza] = useState<PizzaFlavor | null>(null)
  const [editingDrink, setEditingDrink] = useState<Drink | null>(null)
  const [editPizzaName, setEditPizzaName] = useState("")
  const [editDrinkName, setEditDrinkName] = useState("")
  const [editDrinkPrice, setEditDrinkPrice] = useState("")

  const [editingSoda, setEditingSoda] = useState<PersonalSoda | null>(null)
  const [editSodaBrand, setEditSodaBrand] = useState("")
  const [editSodaPrice, setEditSodaPrice] = useState("")

  // Agregar nuevos estados para la selección de múltiples sabores
  const [selectedFlavorCount, setSelectedFlavorCount] = useState<1 | 2 | 3 | 4>(1)
  const [selectedFlavors, setSelectedFlavors] = useState<string[]>([])

  // Agregar nuevo estado después de los otros estados para mesa:
  const [selectedPizzaFlavorForTable, setSelectedPizzaFlavorForTable] = useState("")

  // Agregar nuevo estado para el tipo de empaque después de los otros estados
  const [selectedPackageType, setSelectedPackageType] = useState<"caja" | "bolsa">("caja")

  // Agregar nuevo sabor de pizza
  const addPizzaFlavor = () => {
    if (newFlavorName.trim()) {
      const newFlavor: PizzaFlavor = {
        id: Date.now().toString(),
        name: newFlavorName.trim(),
        available: true,
      }
      setPizzaFlavors([...pizzaFlavors, newFlavor])
      setNewFlavorName("")
    }
  }

  // Editar sabor de pizza
  const editPizzaFlavor = () => {
    if (editingPizza && editPizzaName.trim()) {
      setPizzaFlavors((prev) =>
        prev.map((flavor) => (flavor.id === editingPizza.id ? { ...flavor, name: editPizzaName.trim() } : flavor)),
      )
      setEditingPizza(null)
      setEditPizzaName("")
    }
  }

  // Eliminar sabor de pizza
  const deletePizzaFlavor = (id: string) => {
    setPizzaFlavors((prev) => prev.filter((flavor) => flavor.id !== id))
  }

  // Agregar nueva bebida
  const addDrink = () => {
    if (newDrinkName.trim() && newDrinkPrice) {
      const newDrink: Drink = {
        id: Date.now().toString(),
        name: newDrinkName.trim(),
        price: Number.parseFloat(newDrinkPrice),
        available: true,
      }
      setDrinks([...drinks, newDrink])
      setNewDrinkName("")
      setNewDrinkPrice("")
    }
  }

  // Editar bebida
  const editDrink = () => {
    if (editingDrink && editDrinkName.trim() && editDrinkPrice) {
      setDrinks((prev) =>
        prev.map((drink) =>
          drink.id === editingDrink.id
            ? { ...drink, name: editDrinkName.trim(), price: Number.parseFloat(editDrinkPrice) }
            : drink,
        ),
      )
      setEditingDrink(null)
      setEditDrinkName("")
      setEditDrinkPrice("")
    }
  }

  // Eliminar bebida
  const deleteDrink = (id: string) => {
    setDrinks((prev) => prev.filter((drink) => drink.id !== id))
  }

  // Agregar funciones para manejar gaseosas personales después de las funciones de bebidas

  // Agregar nueva gaseosa personal
  const addPersonalSoda = () => {
    if (newSodaBrand.trim() && newSodaPrice) {
      const newSoda: PersonalSoda = {
        id: Date.now().toString(),
        brand: newSodaBrand.trim(),
        flavors: [{ id: "1", name: "Original", available: true }],
        price: Number.parseFloat(newSodaPrice),
        available: true,
      }
      setPersonalSodas([...personalSodas, newSoda])
      setNewSodaBrand("")
      setNewSodaPrice("")
    }
  }

  // Editar gaseosa personal
  const editPersonalSoda = () => {
    if (editingSoda && editSodaBrand.trim() && editSodaPrice) {
      setPersonalSodas((prev) =>
        prev.map((soda) =>
          soda.id === editingSoda.id
            ? { ...soda, brand: editSodaBrand.trim(), price: Number.parseFloat(editSodaPrice) }
            : soda,
        ),
      )
      setEditingSoda(null)
      setEditSodaBrand("")
      setEditSodaPrice("")
    }
  }

  // Eliminar gaseosa personal
  const deletePersonalSoda = (id: string) => {
    setPersonalSodas((prev) => prev.filter((soda) => soda.id !== id))
  }

  // Agregar sabor a gaseosa
  const addFlavorToSoda = (sodaId: string) => {
    if (newSodaFlavor.trim()) {
      setPersonalSodas((prev) =>
        prev.map((soda) => {
          if (soda.id === sodaId) {
            const newFlavor = {
              id: Date.now().toString(),
              name: newSodaFlavor.trim(),
              available: true,
            }
            return { ...soda, flavors: [...soda.flavors, newFlavor] }
          }
          return soda
        }),
      )
      setNewSodaFlavor("")
    }
  }

  // Eliminar sabor de gaseosa
  const removeFlavorFromSoda = (sodaId: string, flavorId: string) => {
    setPersonalSodas((prev) =>
      prev.map((soda) => {
        if (soda.id === sodaId) {
          return { ...soda, flavors: soda.flavors.filter((flavor) => flavor.id !== flavorId) }
        }
        return soda
      }),
    )
  }

  // Vender gaseosa personal
  const sellPersonalSoda = (sodaId: string, flavorId: string, quantity: number) => {
    const soda = personalSodas.find((s) => s.id === sodaId)
    const flavor = soda?.flavors.find((f) => f.id === flavorId)

    if (soda && flavor && flavor.available) {
      const sale: Sale = {
        id: Date.now().toString(),
        type: "drink",
        item: `${soda.brand} ${flavor.name}`,
        quantity: quantity,
        price: soda.price * quantity,
        timestamp: new Date(),
      }
      setSales((prev) => [...prev, sale])
    }
  }

  // Reemplazar la función addPizzaToInventory con esta nueva versión
  const addPizzaToInventory = () => {
    if (selectedFlavors.length === selectedFlavorCount && selectedFlavors.every((f) => f)) {
      const flavorNames = selectedFlavors
        .map((flavorId) => {
          const flavor = pizzaFlavors.find((f) => f.id === flavorId)
          return flavor ? flavor.name : ""
        })
        .filter((name) => name)

      if (flavorNames.length === selectedFlavorCount) {
        let flavorDistribution: Array<{ name: string; slices: number; remainingSlices: number }> = []

        if (selectedFlavorCount === 1) {
          flavorDistribution = [{ name: flavorNames[0], slices: 12, remainingSlices: 12 }]
        } else if (selectedFlavorCount === 2) {
          flavorDistribution = [
            { name: flavorNames[0], slices: 6, remainingSlices: 6 },
            { name: flavorNames[1], slices: 6, remainingSlices: 6 },
          ]
        } else if (selectedFlavorCount === 3) {
          flavorDistribution = [
            { name: flavorNames[0], slices: 3, remainingSlices: 3 },
            { name: flavorNames[1], slices: 3, remainingSlices: 6 },
            { name: flavorNames[2], slices: 6, remainingSlices: 6 },
          ]
        } else if (selectedFlavorCount === 4) {
          flavorDistribution = [
            { name: flavorNames[0], slices: 3, remainingSlices: 3 },
            { name: flavorNames[1], slices: 3, remainingSlices: 3 },
            { name: flavorNames[2], slices: 3, remainingSlices: 3 },
            { name: flavorNames[3], slices: 3, remainingSlices: 3 },
          ]
        }

        const totalPrice = PIZZA_PRICES[selectedPizzaType]
        const newPizza: PizzaInventory = {
          id: Date.now().toString(),
          flavors: flavorDistribution,
          totalSlices: 12,
          remainingSlices: 12,
          type: selectedPizzaType,
          pricePerSlice: PIZZA_PRICES.perSlice,
          totalPrice: totalPrice,
        }
        setPizzaInventory([...pizzaInventory, newPizza])
        setSelectedFlavors([])
        setSelectedFlavorCount(1)
      }
    }
  }

  // Actualizar la función sellPizzaSlices para manejar múltiples sabores
  const sellPizzaSlices = (pizzaId: string, slices: number, specificFlavor?: string) => {
    setPizzaInventory((prev) =>
      prev.map((pizza) => {
        if (pizza.id === pizzaId && pizza.remainingSlices >= slices) {
          const updatedFlavors = [...pizza.flavors]
          let slicesToSell = slices
          const flavorsSold: string[] = []

          if (specificFlavor) {
            // Vender porciones de un sabor específico
            const flavorIndex = updatedFlavors.findIndex((f) => f.name === specificFlavor)
            if (flavorIndex !== -1 && updatedFlavors[flavorIndex].remainingSlices >= slices) {
              updatedFlavors[flavorIndex].remainingSlices -= slices
              flavorsSold.push(`${slices} de ${specificFlavor}`)
            } else {
              return pizza // No se puede vender
            }
          } else {
            // Vender porciones automáticamente (empezar por el primer sabor disponible)
            for (let i = 0; i < updatedFlavors.length && slicesToSell > 0; i++) {
              const availableSlices = Math.min(updatedFlavors[i].remainingSlices, slicesToSell)
              if (availableSlices > 0) {
                updatedFlavors[i].remainingSlices -= availableSlices
                slicesToSell -= availableSlices
                flavorsSold.push(`${availableSlices} de ${updatedFlavors[i].name}`)
              }
            }
          }

          const newRemainingSlices = updatedFlavors.reduce((sum, f) => sum + f.remainingSlices, 0)

          const sale: Sale = {
            id: Date.now().toString(),
            type: "pizza",
            item: `Pizza (${flavorsSold.join(", ")}) - ${pizza.type === "local" ? "Local" : "Para llevar"}`,
            quantity: slices,
            price: pizza.pricePerSlice * slices,
            timestamp: new Date(),
          }
          setSales((prev) => [...prev, sale])

          return {
            ...pizza,
            flavors: updatedFlavors,
            remainingSlices: newRemainingSlices,
          }
        }
        return pizza
      }),
    )
  }

  // Actualizar la función sellWholePizza
  const sellWholePizza = (pizzaId: string, packageType: "caja" | "bolsa") => {
    setPizzaInventory((prev) =>
      prev.map((pizza) => {
        if (pizza.id === pizzaId && pizza.remainingSlices === 12) {
          const flavorNames = pizza.flavors.map((f) => f.name).join(", ")
          const updatedFlavors = pizza.flavors.map((f) => ({ ...f, remainingSlices: 0 }))
          const packagePrice = packageType === "caja" ? PIZZA_PRICES.caja : PIZZA_PRICES.bolsa

          const sale: Sale = {
            id: Date.now().toString(),
            type: "pizza",
            item: `Pizza completa (${flavorNames}) - ${packageType === "caja" ? "En Caja" : "En Bolsa"}`,
            quantity: 1,
            price: packagePrice,
            timestamp: new Date(),
          }
          setSales((prev) => [...prev, sale])
          return { ...pizza, flavors: updatedFlavors, remainingSlices: 0 }
        }
        return pizza
      }),
    )
  }

  // Agregar gasto
  const addExpense = () => {
    if (expenseDescription.trim() && expenseAmount) {
      const expense: Expense = {
        id: Date.now().toString(),
        description: expenseDescription.trim(),
        amount: Number.parseFloat(expenseAmount),
        timestamp: new Date(),
      }
      setExpenses([...expenses, expense])
      setExpenseDescription("")
      setExpenseAmount("")
    }
  }

  // Vender bebida
  const sellDrink = (drinkId: string, quantity: number) => {
    setDrinks((prev) =>
      prev.map((drink) => {
        if (drink.id === drinkId && drink.available) {
          const sale: Sale = {
            id: Date.now().toString(),
            type: "drink",
            item: drink.name,
            quantity: quantity,
            price: drink.price * quantity,
            timestamp: new Date(),
          }
          setSales((prevSales) => [...prevSales, sale])
          return drink
        }
        return drink
      }),
    )
  }

  // Agregar funciones para el servicio por mesa después de las funciones existentes

  // Ocupar mesa
  const occupyTable = (tableId: number, name: string) => {
    setTables((prev) =>
      prev.map((table) => (table.id === tableId ? { ...table, isOccupied: true, customerName: name } : table)),
    )
    setCustomerName("")
  }

  // Liberar mesa
  const freeTable = (tableId: number) => {
    const table = tables.find((t) => t.id === tableId)
    if (table && table.orders.length > 0) {
      // Agregar todas las órdenes de la mesa a las ventas generales
      table.orders.forEach((order) => {
        const sale: Sale = {
          id: Date.now().toString() + Math.random(),
          type: order.type,
          item: `Mesa ${tableId} - ${order.item}`,
          quantity: order.quantity,
          price: order.price,
          timestamp: new Date(),
        }
        setSales((prev) => [...prev, sale])
      })
    }

    setTables((prev) =>
      prev.map((table) =>
        table.id === tableId
          ? { id: table.id, isOccupied: false, customerName: "", orders: [], totalAmount: 0 }
          : table,
      ),
    )
  }

  // Agregar orden a mesa
  const addOrderToTable = (tableId: number) => {
    let orderItem = ""
    let orderPrice = 0

    if (selectedOrderType === "pizza") {
      const pizza = pizzaInventory.find((p) => p.id === selectedPizzaForTable)
      const selectedFlavor = pizza?.flavors.find((f) => f.name === selectedPizzaFlavorForTable)

      if (pizza && selectedFlavor && selectedFlavor.remainingSlices >= orderQuantity) {
        orderItem = `${selectedPizzaFlavorForTable} (${orderQuantity} porciones)`
        orderPrice = pizza.pricePerSlice * orderQuantity

        // Actualizar inventario de pizza con sabor específico
        sellPizzaSlices(selectedPizzaForTable, orderQuantity, selectedPizzaFlavorForTable)
      } else {
        alert("No hay suficientes porciones disponibles de este sabor")
        return
      }
    } else if (selectedOrderType === "drink") {
      if (selectedDrinkForTable && selectedDrinkForTable !== "none") {
        const drink = drinks.find((d) => d.id === selectedDrinkForTable)
        if (drink) {
          orderItem = drink.name
          orderPrice = drink.price * orderQuantity
        }
      } else if (selectedSodaForTable && selectedSodaFlavorForTable) {
        const soda = personalSodas.find((s) => s.id === selectedSodaForTable)
        const flavor = soda?.flavors.find((f) => f.id === selectedSodaFlavorForTable)
        if (soda && flavor) {
          orderItem = `${soda.brand} ${flavor.name}`
          orderPrice = soda.price * orderQuantity
        }
      }
    }

    if (orderItem && orderPrice > 0) {
      const newOrder = {
        id: Date.now().toString(),
        type: selectedOrderType,
        item: orderItem,
        quantity: orderQuantity,
        price: orderPrice,
        timestamp: new Date(),
      }

      setTables((prev) =>
        prev.map((table) =>
          table.id === tableId
            ? {
                ...table,
                orders: [...table.orders, newOrder],
                totalAmount: table.totalAmount + orderPrice,
              }
            : table,
        ),
      )

      // Limpiar formulario
      setSelectedPizzaForTable("")
      setSelectedPizzaFlavorForTable("")
      setSelectedDrinkForTable("none")
      setSelectedSodaForTable("none")
      setSelectedSodaFlavorForTable("")
      setOrderQuantity(1)
    }
  }

  // Calcular estadísticas
  const totalSales = sales.reduce((sum, sale) => sum + sale.price, 0)
  const totalExpenses = expenses.reduce((sum, expense) => sum + expense.amount, 0)
  const profit = totalSales - totalExpenses

  // Generar reporte
  const generateReport = () => {
    const report = {
      ventas: sales,
      gastos: expenses,
      totalVentas: totalSales,
      totalGastos: totalExpenses,
      ganancia: profit,
      fecha: new Date().toLocaleDateString(),
    }

    const reportText = `
REPORTE DIARIO - ${report.fecha}
================================

VENTAS:
${sales.map((sale) => `- ${sale.item}: $${sale.price.toLocaleString()}`).join("\n")}

GASTOS:
${expenses.map((expense) => `- ${expense.description}: $${expense.amount.toLocaleString()}`).join("\n")}

RESUMEN:
- Total Ventas: $${totalSales.toLocaleString()}
- Total Gastos: $${totalExpenses.toLocaleString()}
- Ganancia: $${profit.toLocaleString()}

PRECIOS DE REFERENCIA:
- Pizza completa (local): $${PIZZA_PRICES.local.toLocaleString()}
- Pizza completa (para llevar): $${PIZZA_PRICES.takeaway.toLocaleString()}
- Precio por porción: $${PIZZA_PRICES.perSlice.toLocaleString()}
    `

    alert(reportText)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-red-50 p-4">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-2 flex items-center justify-center gap-2">
            <Pizza className="h-8 w-8 text-orange-600" />
            La K'zona K'ribean Pizza Gourmet
          </h1>
          <p className="text-gray-600">Panel de control de gestión de La K'zona K'ribean</p>
        </div>

        <Tabs defaultValue="products" className="space-y-6">
          {/* Actualizar el TabsList para incluir la nueva sección */}
          {/* Cambiar de grid-cols-4 a grid-cols-5 */}
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="products">Productos</TabsTrigger>
            <TabsTrigger value="inventory">Inventario & Ventas</TabsTrigger>
            <TabsTrigger value="tables">Servicio Por Mesa</TabsTrigger>
            <TabsTrigger value="expenses">Gastos</TabsTrigger>
            <TabsTrigger value="reports">Reportes</TabsTrigger>
          </TabsList>

          {/* Gestión de Productos */}
          <TabsContent value="products" className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              {/* Sabores de Pizza */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Pizza className="h-5 w-5" />
                    Sabores de Pizza
                  </CardTitle>
                  <CardDescription>
                    Gestiona los sabores disponibles
                    <br />
                    <span className="text-xs">
                      En Bolsa: ${PIZZA_PRICES.bolsa.toLocaleString()} | En Caja: ${PIZZA_PRICES.caja.toLocaleString()}{" "}
                      | Por porción: ${PIZZA_PRICES.perSlice.toLocaleString()}
                    </span>
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex gap-2">
                    <Input
                      placeholder="Nombre del sabor"
                      value={newFlavorName}
                      onChange={(e) => setNewFlavorName(e.target.value)}
                    />
                    <Button onClick={addPizzaFlavor}>
                      <Plus className="h-4 w-4" />
                    </Button>
                  </div>

                  <div className="space-y-2">
                    {pizzaFlavors.map((flavor) => (
                      <div key={flavor.id} className="flex items-center justify-between p-3 border rounded-lg">
                        <div>
                          <span className="font-medium">{flavor.name}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Badge variant={flavor.available ? "default" : "secondary"}>
                            {flavor.available ? "Disponible" : "No disponible"}
                          </Badge>

                          <Dialog>
                            <DialogTrigger asChild>
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => {
                                  setEditingPizza(flavor)
                                  setEditPizzaName(flavor.name)
                                }}
                              >
                                <Edit className="h-4 w-4" />
                              </Button>
                            </DialogTrigger>
                            <DialogContent>
                              <DialogHeader>
                                <DialogTitle>Editar Sabor de Pizza</DialogTitle>
                                <DialogDescription>Modifica el nombre del sabor de pizza</DialogDescription>
                              </DialogHeader>
                              <div className="space-y-4">
                                <div>
                                  <Label>Nombre del sabor</Label>
                                  <Input value={editPizzaName} onChange={(e) => setEditPizzaName(e.target.value)} />
                                </div>
                              </div>
                              <DialogFooter>
                                <Button onClick={editPizzaFlavor}>Guardar cambios</Button>
                              </DialogFooter>
                            </DialogContent>
                          </Dialog>

                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() =>
                              setPizzaFlavors((prev) =>
                                prev.map((f) => (f.id === flavor.id ? { ...f, available: !f.available } : f)),
                              )
                            }
                          >
                            {flavor.available ? "Desactivar" : "Activar"}
                          </Button>

                          <Button size="sm" variant="destructive" onClick={() => deletePizzaFlavor(flavor.id)}>
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Bebidas */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Coffee className="h-5 w-5" />
                    Bebidas
                  </CardTitle>
                  <CardDescription>Gestiona todas las bebidas disponibles</CardDescription>
                </CardHeader>
                <CardContent>
                  <Tabs defaultValue="generales" className="w-full">
                    <TabsList className="grid w-full grid-cols-2">
                      <TabsTrigger value="generales">Generales</TabsTrigger>
                      <TabsTrigger value="personales">Personales</TabsTrigger>
                    </TabsList>

                    {/* Bebidas Generales */}
                    <TabsContent value="generales" className="space-y-4 mt-4">
                      <div className="flex gap-2">
                        <Input
                          placeholder="Nombre de la bebida"
                          value={newDrinkName}
                          onChange={(e) => setNewDrinkName(e.target.value)}
                        />
                        <Input
                          placeholder="Precio"
                          type="number"
                          value={newDrinkPrice}
                          onChange={(e) => setNewDrinkPrice(e.target.value)}
                        />
                        <Button onClick={addDrink}>
                          <Plus className="h-4 w-4" />
                        </Button>
                      </div>

                      <div className="space-y-2 max-h-80 overflow-y-auto">
                        {drinks.map((drink) => (
                          <div key={drink.id} className="flex items-center justify-between p-3 border rounded-lg">
                            <div>
                              <span className="font-medium">{drink.name}</span>
                              <span className="text-sm text-gray-500 ml-2">${drink.price.toLocaleString()}</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <Badge variant={drink.available ? "default" : "secondary"}>
                                {drink.available ? "Disponible" : "No disponible"}
                              </Badge>

                              <Dialog>
                                <DialogTrigger asChild>
                                  <Button
                                    size="sm"
                                    variant="outline"
                                    onClick={() => {
                                      setEditingDrink(drink)
                                      setEditDrinkName(drink.name)
                                      setEditDrinkPrice(drink.price.toString())
                                    }}
                                  >
                                    <Edit className="h-4 w-4" />
                                  </Button>
                                </DialogTrigger>
                                <DialogContent>
                                  <DialogHeader>
                                    <DialogTitle>Editar Bebida</DialogTitle>
                                    <DialogDescription>Modifica el nombre y precio de la bebida</DialogDescription>
                                  </DialogHeader>
                                  <div className="space-y-4">
                                    <div>
                                      <Label>Nombre de la bebida</Label>
                                      <Input value={editDrinkName} onChange={(e) => setEditDrinkName(e.target.value)} />
                                    </div>
                                    <div>
                                      <Label>Precio</Label>
                                      <Input
                                        type="number"
                                        value={editDrinkPrice}
                                        onChange={(e) => setEditDrinkPrice(e.target.value)}
                                      />
                                    </div>
                                  </div>
                                  <DialogFooter>
                                    <Button onClick={editDrink}>Guardar cambios</Button>
                                  </DialogFooter>
                                </DialogContent>
                              </Dialog>

                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() =>
                                  setDrinks((prev) =>
                                    prev.map((d) => (d.id === drink.id ? { ...d, available: !d.available } : d)),
                                  )
                                }
                              >
                                {drink.available ? "Desactivar" : "Activar"}
                              </Button>

                              <Button size="sm" variant="destructive" onClick={() => deleteDrink(drink.id)}>
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          </div>
                        ))}
                      </div>
                    </TabsContent>

                    {/* Gaseosas Personales */}
                    <TabsContent value="personales" className="space-y-4 mt-4">
                      <div className="flex gap-2">
                        <Input
                          placeholder="Marca de gaseosa"
                          value={newSodaBrand}
                          onChange={(e) => setNewSodaBrand(e.target.value)}
                        />
                        <Input
                          placeholder="Precio"
                          type="number"
                          value={newSodaPrice}
                          onChange={(e) => setNewSodaPrice(e.target.value)}
                        />
                        <Button onClick={addPersonalSoda}>
                          <Plus className="h-4 w-4" />
                        </Button>
                      </div>

                      <div className="space-y-4 max-h-80 overflow-y-auto">
                        {personalSodas.map((soda) => (
                          <div key={soda.id} className="border rounded-lg p-4">
                            <div className="flex items-center justify-between mb-3">
                              <div>
                                <span className="font-medium text-lg">{soda.brand}</span>
                                <span className="text-sm text-gray-500 ml-2">${soda.price.toLocaleString()}</span>
                              </div>
                              <div className="flex items-center gap-2">
                                <Badge variant={soda.available ? "default" : "secondary"}>
                                  {soda.available ? "Disponible" : "No disponible"}
                                </Badge>

                                <Dialog>
                                  <DialogTrigger asChild>
                                    <Button
                                      size="sm"
                                      variant="outline"
                                      onClick={() => {
                                        setEditingSoda(soda)
                                        setEditSodaBrand(soda.brand)
                                        setEditSodaPrice(soda.price.toString())
                                      }}
                                    >
                                      <Edit className="h-4 w-4" />
                                    </Button>
                                  </DialogTrigger>
                                  <DialogContent>
                                    <DialogHeader>
                                      <DialogTitle>Editar Gaseosa</DialogTitle>
                                      <DialogDescription>Modifica la marca y precio de la gaseosa</DialogDescription>
                                    </DialogHeader>
                                    <div className="space-y-4">
                                      <div>
                                        <Label>Marca de la gaseosa</Label>
                                        <Input
                                          value={editSodaBrand}
                                          onChange={(e) => setEditSodaBrand(e.target.value)}
                                        />
                                      </div>
                                      <div>
                                        <Label>Precio</Label>
                                        <Input
                                          type="number"
                                          value={editSodaPrice}
                                          onChange={(e) => setEditSodaPrice(e.target.value)}
                                        />
                                      </div>
                                    </div>
                                    <DialogFooter>
                                      <Button onClick={editPersonalSoda}>Guardar cambios</Button>
                                    </DialogFooter>
                                  </DialogContent>
                                </Dialog>

                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() =>
                                    setPersonalSodas((prev) =>
                                      prev.map((s) => (s.id === soda.id ? { ...s, available: !s.available } : s)),
                                    )
                                  }
                                >
                                  {soda.available ? "Desactivar" : "Activar"}
                                </Button>

                                <Button size="sm" variant="destructive" onClick={() => deletePersonalSoda(soda.id)}>
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </div>
                            </div>

                            {/* Sabores de la gaseosa */}
                            <div className="space-y-2">
                              <Label className="text-sm font-medium">Sabores disponibles:</Label>

                              <div className="flex gap-2 mb-2">
                                <Input
                                  placeholder="Nuevo sabor"
                                  value={newSodaFlavor}
                                  onChange={(e) => setNewSodaFlavor(e.target.value)}
                                  size="sm"
                                />
                                <Button size="sm" onClick={() => addFlavorToSoda(soda.id)}>
                                  <Plus className="h-3 w-3" />
                                </Button>
                              </div>

                              <div className="grid grid-cols-1 gap-2">
                                {soda.flavors.map((flavor) => (
                                  <div
                                    key={flavor.id}
                                    className="flex items-center justify-between p-2 bg-gray-50 rounded"
                                  >
                                    <div className="flex items-center gap-2">
                                      <span className="text-sm font-medium">{flavor.name}</span>
                                      <Badge size="sm" variant={flavor.available ? "default" : "secondary"}>
                                        {flavor.available ? "Disponible" : "No disponible"}
                                      </Badge>
                                    </div>
                                    <div className="flex gap-1">
                                      <Button
                                        size="sm"
                                        variant="ghost"
                                        onClick={() =>
                                          setPersonalSodas((prev) =>
                                            prev.map((s) =>
                                              s.id === soda.id
                                                ? {
                                                    ...s,
                                                    flavors: s.flavors.map((f) =>
                                                      f.id === flavor.id ? { ...f, available: !f.available } : f,
                                                    ),
                                                  }
                                                : s,
                                            ),
                                          )
                                        }
                                      >
                                        {flavor.available ? "Desactivar" : "Activar"}
                                      </Button>
                                      <Button
                                        size="sm"
                                        variant="ghost"
                                        onClick={() => removeFlavorFromSoda(soda.id, flavor.id)}
                                      >
                                        <Trash2 className="h-3 w-3" />
                                      </Button>
                                    </div>
                                  </div>
                                ))}
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </TabsContent>
                  </Tabs>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Inventario y Ventas */}
          <TabsContent value="inventory" className="space-y-6">
            <div className="grid lg:grid-cols-3 gap-6">
              {/* Agregar Pizza al Inventario */}
              <Card>
                <CardHeader>
                  <CardTitle>Agregar Pizza Completa</CardTitle>
                  <CardDescription>Cada pizza tiene 12 porciones</CardDescription>
                </CardHeader>

                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label>Cantidad de sabores</Label>
                    <Select
                      value={selectedFlavorCount.toString()}
                      onValueChange={(value) => {
                        const count = Number.parseInt(value) as 1 | 2 | 3 | 4
                        setSelectedFlavorCount(count)
                        setSelectedFlavors(new Array(count).fill(""))
                      }}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="1">1 sabor (12 porciones)</SelectItem>
                        <SelectItem value="2">2 sabores (6 + 6 porciones)</SelectItem>
                        <SelectItem value="3">3 sabores (3 + 3 + 6 porciones)</SelectItem>
                        <SelectItem value="4">4 sabores (3 + 3 + 3 + 3 porciones)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  {Array.from({ length: selectedFlavorCount }, (_, index) => {
                    const sliceCount =
                      selectedFlavorCount === 1
                        ? 12
                        : selectedFlavorCount === 2
                          ? 6
                          : selectedFlavorCount === 3 && index === 2
                            ? 6
                            : 3

                    return (
                      <div key={index} className="space-y-2">
                        <Label>
                          Sabor {index + 1} ({sliceCount} porciones)
                        </Label>
                        <Select
                          value={selectedFlavors[index] || ""}
                          onValueChange={(value) => {
                            const newFlavors = [...selectedFlavors]
                            newFlavors[index] = value
                            setSelectedFlavors(newFlavors)
                          }}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Seleccionar sabor" />
                          </SelectTrigger>
                          <SelectContent>
                            {pizzaFlavors
                              .filter((f) => f.available)
                              .map((flavor) => (
                                <SelectItem key={flavor.id} value={flavor.id}>
                                  {flavor.name}
                                </SelectItem>
                              ))}
                          </SelectContent>
                        </Select>
                      </div>
                    )
                  })}

                  <Select
                    value={selectedPizzaType}
                    onValueChange={(value: "local" | "takeaway") => setSelectedPizzaType(value)}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="local">Para consumir aquí (${PIZZA_PRICES.local.toLocaleString()})</SelectItem>
                      <SelectItem value="takeaway">Para llevar (${PIZZA_PRICES.takeaway.toLocaleString()})</SelectItem>
                    </SelectContent>
                  </Select>

                  <Button
                    onClick={addPizzaToInventory}
                    className="w-full"
                    disabled={selectedFlavors.length !== selectedFlavorCount || selectedFlavors.some((f) => !f)}
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    Agregar Pizza
                  </Button>
                </CardContent>
              </Card>

              {/* Inventario de Pizzas */}
              <Card className="lg:col-span-2">
                <CardHeader>
                  <CardTitle>Inventario de Pizzas</CardTitle>
                  <CardDescription>Pizzas disponibles y porciones restantes</CardDescription>
                </CardHeader>
                <CardContent>
                  {pizzaInventory.length === 0 ? (
                    <Alert>
                      <Package className="h-4 w-4" />
                      <AlertDescription>
                        No hay pizzas en inventario. Agrega una pizza completa para comenzar.
                      </AlertDescription>
                    </Alert>
                  ) : (
                    <div className="space-y-4">
                      {pizzaInventory.map((pizza) => (
                        <div key={pizza.id} className="border rounded-lg p-4">
                          <div className="flex items-center justify-between mb-3">
                            <div>
                              <h3 className="font-semibold">
                                Pizza {pizza.flavors.length > 1 ? "Mixta" : pizza.flavors[0]?.name}
                              </h3>
                              <div className="text-sm text-gray-600">
                                {pizza.flavors.map((flavor, index) => (
                                  <div key={index}>
                                    • {flavor.name}: {flavor.remainingSlices}/{flavor.slices} porciones
                                  </div>
                                ))}
                              </div>
                              <p className="text-sm text-gray-500 mt-1">
                                {pizza.type === "local" ? "Para consumir aquí" : "Para llevar"} - $
                                {pizza.pricePerSlice.toLocaleString()} por porción
                              </p>
                            </div>
                            <Badge variant={pizza.remainingSlices > 0 ? "default" : "destructive"}>
                              {pizza.remainingSlices}/{pizza.totalSlices} porciones
                            </Badge>
                          </div>

                          {/* Venta por sabores específicos */}
                          {pizza.flavors.length > 1 && (
                            <div className="mb-3">
                              <Label className="text-sm font-medium">Vender por sabor:</Label>
                              <div className="grid grid-cols-1 gap-2 mt-2">
                                {pizza.flavors.map((flavor, index) => (
                                  <div key={index} className="flex items-center justify-between p-2 bg-gray-50 rounded">
                                    <span className="text-sm">
                                      {flavor.name} ({flavor.remainingSlices} disponibles)
                                    </span>
                                    <div className="flex gap-1">
                                      {[1, 2, 3].map((slices) => (
                                        <Button
                                          key={slices}
                                          size="sm"
                                          variant="outline"
                                          disabled={flavor.remainingSlices < slices}
                                          onClick={() => sellPizzaSlices(pizza.id, slices, flavor.name)}
                                        >
                                          {slices}
                                        </Button>
                                      ))}
                                    </div>
                                  </div>
                                ))}
                              </div>
                            </div>
                          )}

                          <div className="flex items-center gap-2 mb-2">
                            <Label>Vender porciones mixtas:</Label>
                            {[1, 2, 3, 4, 6].map((slices) => (
                              <Button
                                key={slices}
                                size="sm"
                                variant="outline"
                                disabled={pizza.remainingSlices < slices}
                                onClick={() => sellPizzaSlices(pizza.id, slices)}
                              >
                                {slices}
                              </Button>
                            ))}
                          </div>

                          {pizza.remainingSlices === 12 && (
                            <div className="space-y-2 mb-2">
                              <Label className="text-sm font-medium">Vender pizza completa:</Label>
                              <div className="flex gap-2">
                                <Button size="sm" onClick={() => sellWholePizza(pizza.id, "bolsa")} className="flex-1">
                                  <ShoppingCart className="h-4 w-4 mr-1" />
                                  En Bolsa (${PIZZA_PRICES.bolsa.toLocaleString()})
                                </Button>
                                <Button size="sm" onClick={() => sellWholePizza(pizza.id, "caja")} className="flex-1">
                                  <ShoppingCart className="h-4 w-4 mr-1" />
                                  En Caja (${PIZZA_PRICES.caja.toLocaleString()})
                                </Button>
                              </div>
                            </div>
                          )}

                          <div className="space-y-1">
                            {pizza.flavors.map((flavor, index) => (
                              <div key={index} className="flex items-center gap-2 text-xs">
                                <span className="w-20 truncate">{flavor.name}:</span>
                                <div className="flex-1 bg-gray-200 rounded-full h-1.5">
                                  <div
                                    className="bg-orange-500 h-1.5 rounded-full transition-all"
                                    style={{
                                      width: `${(flavor.remainingSlices / flavor.slices) * 100}%`,
                                    }}
                                  />
                                </div>
                                <span>
                                  {flavor.remainingSlices}/{flavor.slices}
                                </span>
                              </div>
                            ))}
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>

            {/* Venta de Bebidas */}
            <Card>
              <CardHeader>
                <CardTitle>Vender Bebidas</CardTitle>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="generales" className="w-full">
                  <TabsList className="grid w-full grid-cols-2">
                    <TabsTrigger value="generales">Generales</TabsTrigger>
                    <TabsTrigger value="personales">Personales</TabsTrigger>
                  </TabsList>

                  {/* Bebidas Generales */}
                  <TabsContent value="generales" className="mt-4">
                    <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                      {drinks
                        .filter((d) => d.available)
                        .map((drink) => (
                          <div key={drink.id} className="flex items-center justify-between p-3 border rounded-lg">
                            <div>
                              <span className="font-medium">{drink.name}</span>
                              <span className="text-sm text-gray-500 block">${drink.price.toLocaleString()}</span>
                            </div>
                            <div className="flex items-center gap-1">
                              {[1, 2, 3, 5].map((qty) => (
                                <Button key={qty} size="sm" variant="outline" onClick={() => sellDrink(drink.id, qty)}>
                                  {qty}
                                </Button>
                              ))}
                            </div>
                          </div>
                        ))}
                    </div>
                  </TabsContent>

                  {/* Gaseosas Personales */}
                  <TabsContent value="personales" className="mt-4">
                    <div className="space-y-4">
                      {personalSodas
                        .filter((soda) => soda.available)
                        .map((soda) => (
                          <div key={soda.id} className="border rounded-lg p-4">
                            <h3 className="font-semibold text-lg mb-3">
                              {soda.brand} - ${soda.price.toLocaleString()}
                            </h3>
                            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-3">
                              {soda.flavors
                                .filter((flavor) => flavor.available)
                                .map((flavor) => (
                                  <div
                                    key={flavor.id}
                                    className="flex items-center justify-between p-3 bg-gray-50 rounded-lg"
                                  >
                                    <div>
                                      <span className="font-medium">{flavor.name}</span>
                                      <span className="text-sm text-gray-500 block">
                                        ${soda.price.toLocaleString()}
                                      </span>
                                    </div>
                                    <div className="flex items-center gap-1">
                                      {[1, 2, 3, 5].map((qty) => (
                                        <Button
                                          key={qty}
                                          size="sm"
                                          variant="outline"
                                          onClick={() => sellPersonalSoda(soda.id, flavor.id, qty)}
                                        >
                                          {qty}
                                        </Button>
                                      ))}
                                    </div>
                                  </div>
                                ))}
                            </div>
                          </div>
                        ))}
                    </div>
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>

            {/* Lista de Ventas del Día */}
            <Card>
              <CardHeader>
                <CardTitle>Ventas del Día</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 max-h-60 overflow-y-auto">
                  {sales.length === 0 ? (
                    <p className="text-gray-500 text-center py-4">No hay ventas registradas</p>
                  ) : (
                    sales.map((sale) => (
                      <div key={sale.id} className="flex justify-between items-center p-2 border-b">
                        <div>
                          <span className="font-medium">{sale.item}</span>
                          <span className="text-xs text-gray-500 block">{sale.timestamp.toLocaleTimeString()}</span>
                        </div>
                        <span className="font-semibold text-green-600">${sale.price.toLocaleString()}</span>
                      </div>
                    ))
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Servicio Por Mesa */}
          <TabsContent value="tables" className="space-y-6">
            <div className="grid lg:grid-cols-4 gap-6">
              {/* Vista de Mesas */}
              <Card className="lg:col-span-3">
                <CardHeader>
                  <CardTitle>Estado de las Mesas</CardTitle>
                  <CardDescription>Gestiona las 9 mesas disponibles</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-3 gap-4">
                    {tables.map((table) => (
                      <div
                        key={table.id}
                        className={`relative p-4 border-2 rounded-lg cursor-pointer transition-all ${
                          table.isOccupied
                            ? "border-red-500 bg-red-50"
                            : "border-green-500 bg-green-50 hover:bg-green-100"
                        }`}
                        onClick={() => setSelectedTable(table.id)}
                      >
                        <div className="text-center">
                          <h3 className="text-lg font-bold">Mesa {table.id}</h3>
                          <div className="mt-2">
                            {table.isOccupied ? (
                              <div>
                                <Badge variant="destructive" className="mb-2">
                                  Ocupada
                                </Badge>
                                <p className="text-sm font-medium">{table.customerName}</p>
                                <p className="text-xs text-gray-600">{table.orders.length} órdenes</p>
                                <p className="text-sm font-bold text-green-600">
                                  ${table.totalAmount.toLocaleString()}
                                </p>
                              </div>
                            ) : (
                              <Badge variant="default">Disponible</Badge>
                            )}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Panel de Control de Mesa */}
              <Card>
                <CardHeader>
                  <CardTitle>{selectedTable ? `Mesa ${selectedTable}` : "Selecciona una Mesa"}</CardTitle>
                  <CardDescription>
                    {selectedTable
                      ? tables.find((t) => t.id === selectedTable)?.isOccupied
                        ? "Tomar pedido"
                        : "Ocupar mesa"
                      : "Haz clic en una mesa para gestionarla"}
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {selectedTable && (
                    <>
                      {!tables.find((t) => t.id === selectedTable)?.isOccupied ? (
                        // Formulario para ocupar mesa
                        <div className="space-y-4">
                          <div>
                            <Label>Nombre del cliente</Label>
                            <Input
                              placeholder="Nombre del cliente"
                              value={customerName}
                              onChange={(e) => setCustomerName(e.target.value)}
                            />
                          </div>
                          <Button
                            onClick={() => occupyTable(selectedTable, customerName)}
                            className="w-full"
                            disabled={!customerName.trim()}
                          >
                            Ocupar Mesa {selectedTable}
                          </Button>
                        </div>
                      ) : (
                        // Formulario para tomar pedido
                        <div className="space-y-4">
                          <div className="text-sm bg-gray-100 p-2 rounded">
                            <strong>Cliente:</strong> {tables.find((t) => t.id === selectedTable)?.customerName}
                          </div>

                          <div>
                            <Label>Tipo de pedido</Label>
                            <Select
                              value={selectedOrderType}
                              onValueChange={(value: "pizza" | "drink") => setSelectedOrderType(value)}
                            >
                              <SelectTrigger>
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="pizza">Pizza</SelectItem>
                                <SelectItem value="drink">Bebida</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>

                          {selectedOrderType === "pizza" && (
                            <>
                              <div>
                                <Label>Seleccionar Pizza</Label>
                                <Select value={selectedPizzaForTable} onValueChange={setSelectedPizzaForTable}>
                                  <SelectTrigger>
                                    <SelectValue placeholder="Seleccionar pizza" />
                                  </SelectTrigger>
                                  <SelectContent>
                                    {pizzaInventory
                                      .filter((p) => p.remainingSlices > 0)
                                      .map((pizza) => (
                                        <SelectItem key={pizza.id} value={pizza.id}>
                                          {pizza.flavors.map((f) => f.name).join(", ")} ({pizza.remainingSlices}
                                          porciones)
                                        </SelectItem>
                                      ))}
                                  </SelectContent>
                                </Select>
                              </div>

                              {selectedPizzaForTable && (
                                <div>
                                  <Label>Seleccionar Sabor</Label>
                                  <Select
                                    value={selectedPizzaFlavorForTable}
                                    onValueChange={setSelectedPizzaFlavorForTable}
                                  >
                                    <SelectTrigger>
                                      <SelectValue placeholder="Seleccionar sabor" />
                                    </SelectTrigger>
                                    <SelectContent>
                                      {pizzaInventory
                                        .find((p) => p.id === selectedPizzaForTable)
                                        ?.flavors.filter((f) => f.remainingSlices > 0)
                                        .map((flavor, index) => (
                                          <SelectItem key={index} value={flavor.name}>
                                            {flavor.name} ({flavor.remainingSlices} porciones disponibles)
                                          </SelectItem>
                                        ))}
                                    </SelectContent>
                                  </Select>
                                </div>
                              )}
                            </>
                          )}

                          {selectedOrderType === "drink" && (
                            <>
                              <div>
                                <Label>Bebidas Generales</Label>
                                <Select
                                  value={selectedDrinkForTable}
                                  onValueChange={(value) => {
                                    setSelectedDrinkForTable(value)
                                    setSelectedSodaForTable("none")
                                    setSelectedSodaFlavorForTable("")
                                  }}
                                >
                                  <SelectTrigger>
                                    <SelectValue placeholder="Seleccionar bebida" />
                                  </SelectTrigger>
                                  <SelectContent>
                                    <SelectItem value="none">-- Ninguna --</SelectItem>
                                    {drinks
                                      .filter((d) => d.available)
                                      .map((drink) => (
                                        <SelectItem key={drink.id} value={drink.id}>
                                          {drink.name} - ${drink.price.toLocaleString()}
                                        </SelectItem>
                                      ))}
                                  </SelectContent>
                                </Select>
                              </div>

                              <div>
                                <Label>Gaseosas Personales</Label>
                                <Select
                                  value={selectedSodaForTable}
                                  onValueChange={(value) => {
                                    setSelectedSodaForTable(value)
                                    setSelectedDrinkForTable("none")
                                    setSelectedSodaFlavorForTable("")
                                  }}
                                >
                                  <SelectTrigger>
                                    <SelectValue placeholder="Seleccionar gaseosa" />
                                  </SelectTrigger>
                                  <SelectContent>
                                    <SelectItem value="none">-- Ninguna --</SelectItem>
                                    {personalSodas
                                      .filter((s) => s.available)
                                      .map((soda) => (
                                        <SelectItem key={soda.id} value={soda.id}>
                                          {soda.brand} - ${soda.price.toLocaleString()}
                                        </SelectItem>
                                      ))}
                                  </SelectContent>
                                </Select>
                              </div>

                              {selectedSodaForTable && (
                                <div>
                                  <Label>Sabor</Label>
                                  <Select
                                    value={selectedSodaFlavorForTable}
                                    onValueChange={setSelectedSodaFlavorForTable}
                                  >
                                    <SelectTrigger>
                                      <SelectValue placeholder="Seleccionar sabor" />
                                    </SelectTrigger>
                                    <SelectContent>
                                      {personalSodas
                                        .find((s) => s.id === selectedSodaForTable)
                                        ?.flavors.filter((f) => f.available)
                                        .map((flavor) => (
                                          <SelectItem key={flavor.id} value={flavor.id}>
                                            {flavor.name}
                                          </SelectItem>
                                        ))}
                                    </SelectContent>
                                  </Select>
                                </div>
                              )}
                            </>
                          )}

                          <div>
                            <Label>Cantidad</Label>
                            <Select
                              value={orderQuantity.toString()}
                              onValueChange={(value) => setOrderQuantity(Number.parseInt(value))}
                            >
                              <SelectTrigger>
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                {[1, 2, 3, 4, 5, 6].map((qty) => (
                                  <SelectItem key={qty} value={qty.toString()}>
                                    {qty}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          </div>

                          <Button
                            onClick={() => addOrderToTable(selectedTable)}
                            className="w-full"
                            disabled={
                              selectedOrderType === "pizza"
                                ? !selectedPizzaForTable || !selectedPizzaFlavorForTable
                                : (selectedDrinkForTable === "none" || !selectedDrinkForTable) &&
                                  !selectedSodaFlavorForTable
                            }
                          >
                            <Plus className="h-4 w-4 mr-2" />
                            Agregar al Pedido
                          </Button>

                          <div className="border-t pt-4">
                            <Button onClick={() => freeTable(selectedTable)} variant="outline" className="w-full">
                              <ShoppingCart className="h-4 w-4 mr-2" />
                              Finalizar y Cobrar Mesa
                            </Button>
                          </div>
                        </div>
                      )}
                    </>
                  )}
                </CardContent>
              </Card>
            </div>

            {/* Pedidos de la Mesa Seleccionada */}
            {selectedTable && tables.find((t) => t.id === selectedTable)?.isOccupied && (
              <Card>
                <CardHeader>
                  <CardTitle>Pedidos de Mesa {selectedTable}</CardTitle>
                  <CardDescription>Cliente: {tables.find((t) => t.id === selectedTable)?.customerName}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {tables
                      .find((t) => t.id === selectedTable)
                      ?.orders.map((order) => (
                        <div key={order.id} className="flex justify-between items-center p-3 border rounded-lg">
                          <div>
                            <span className="font-medium">{order.item}</span>
                            <span className="text-sm text-gray-500 ml-2">x{order.quantity}</span>
                            <span className="text-xs text-gray-500 block">{order.timestamp.toLocaleTimeString()}</span>
                          </div>
                          <span className="font-semibold text-green-600">${order.price.toLocaleString()}</span>
                        </div>
                      ))}

                    {tables.find((t) => t.id === selectedTable)?.orders.length === 0 && (
                      <p className="text-gray-500 text-center py-4">No hay pedidos aún</p>
                    )}

                    {tables.find((t) => t.id === selectedTable)?.orders.length > 0 && (
                      <div className="border-t pt-4 flex justify-between items-center">
                        <span className="text-lg font-bold">Total:</span>
                        <span className="text-xl font-bold text-green-600">
                          ${tables.find((t) => t.id === selectedTable)?.totalAmount.toLocaleString()}
                        </span>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          {/* Solo Gastos */}
          <TabsContent value="expenses" className="space-y-6">
            <div className="grid lg:grid-cols-2 gap-6">
              {/* Registro de Gastos */}
              <Card>
                <CardHeader>
                  <CardTitle>Registrar Gastos</CardTitle>
                  <CardDescription>Anota todos los gastos del día</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label>Descripción del gasto</Label>
                    <Textarea
                      placeholder="Ej: Ingredientes, gas, servicios, etc."
                      value={expenseDescription}
                      onChange={(e) => setExpenseDescription(e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Monto</Label>
                    <Input
                      type="number"
                      placeholder="0"
                      value={expenseAmount}
                      onChange={(e) => setExpenseAmount(e.target.value)}
                    />
                  </div>
                  <Button onClick={addExpense} className="w-full">
                    <Plus className="h-4 w-4 mr-2" />
                    Agregar Gasto
                  </Button>
                </CardContent>
              </Card>

              {/* Lista de Gastos */}
              <Card>
                <CardHeader>
                  <CardTitle>Gastos del Día</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 max-h-60 overflow-y-auto">
                    {expenses.length === 0 ? (
                      <p className="text-gray-500 text-center py-4">No hay gastos registrados</p>
                    ) : (
                      expenses.map((expense) => (
                        <div key={expense.id} className="flex justify-between items-center p-2 border-b">
                          <div>
                            <span className="font-medium">{expense.description}</span>
                            <span className="text-xs text-gray-500 block">
                              {expense.timestamp.toLocaleTimeString()}
                            </span>
                          </div>
                          <span className="font-semibold text-red-600">-${expense.amount.toLocaleString()}</span>
                        </div>
                      ))
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Reportes */}
          <TabsContent value="reports" className="space-y-6">
            <div className="grid md:grid-cols-3 gap-6 mb-6">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total Ventas</CardTitle>
                  <DollarSign className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-green-600">${totalSales.toLocaleString()}</div>
                  <p className="text-xs text-muted-foreground">{sales.length} ventas realizadas</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total Gastos</CardTitle>
                  <Minus className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-red-600">${totalExpenses.toLocaleString()}</div>
                  <p className="text-xs text-muted-foreground">{expenses.length} gastos registrados</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Ganancia</CardTitle>
                  <BarChart3 className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className={`text-2xl font-bold ${profit >= 0 ? "text-green-600" : "text-red-600"}`}>
                    ${profit.toLocaleString()}
                  </div>
                  <p className="text-xs text-muted-foreground">
                    {profit >= 0 ? "Ganancia del día" : "Pérdida del día"}
                  </p>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Generar Reporte Final</CardTitle>
                <CardDescription>Genera un reporte completo con todas las estadísticas del día</CardDescription>
              </CardHeader>
              <CardContent>
                <Button onClick={generateReport} size="lg" className="w-full">
                  <BarChart3 className="h-4 w-4 mr-2" />
                  Generar Reporte Completo
                </Button>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
